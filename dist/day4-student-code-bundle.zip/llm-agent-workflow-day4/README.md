# 4주차 PR 리뷰와 문서 자동화

## 시작

압축을 풀고 이 README가 있는 폴더 전체를 VS Code로 엽니다. Notebook만 따로 복사하지 않습니다.

1. Python 3.12 권장. 본인의 가상환경을 선택합니다.
2. 아래 명령을 터미널에서 실행합니다.
3. Notebook을 위에서부터 실행하고 차시별 ‘직접 수정 구간’을 진행합니다.

```bash
python -m pip install -r requirements-day4.txt
python -m jupyter lab materials/day4/day4_pr_document_automation.ipynb
```

Mac에서는 환경에 따라 python3을 사용합니다. Windows는 `py -3.12 -m venv .venv` 다음
`.venv\Scripts\python.exe -m pip install -r requirements-day4.txt`처럼 Python을 직접 지정할 수 있습니다.

PPT 생성은 Node.js 설치 후 다음 명령을 한 번 실행합니다.

```bash
npm install --prefix labs/day4/office_lab/presentations
```

## 자료

- [수강생 실습 가이드](materials/day4/2026_Day4_수강생_실습가이드.md)
- [실습 Notebook](materials/day4/day4_pr_document_automation.ipynb)
- [실행 결과 비교용 Notebook](materials/day4/day4_pr_document_automation.executed.ipynb)
- [PR 리뷰와 CI](materials/day4/pr_lab_contract.md)
- [Excel WBS와 채점](materials/day4/excel_lab_contract.md)
- [Word와 PPT](materials/day4/document_lab_contract.md)
- 참고 문서: `outputs/day4-document-automation/`

Excel 템플릿은 WBS 14개 작업, 시험 40문항·28명 합성 데이터입니다.
`outputs/day4-document-automation/`의 파일은 실습 코드가 읽는 양식이므로 폴더 구조를 유지합니다.
기본 과정은 API key·LLM 계정·GitHub 게시 없이 실행됩니다. Codex·Claude 대화 과제는 본인 계정에서 선택합니다.

선택 Codex 실시간 리뷰는 CLI 로그인과 계정 사용량이 필요합니다. 공개 예시 세 파일을 읽어
새 Markdown으로 저장하며 실패하면 fixture로 바꾸지 않습니다.

```bash
python -m labs.day4.pr_review_lab.codex_review --live --output output/my-review.md
```

`--live`를 빼면 호출하지 않습니다. 모델이 반환한 파일 줄 번호와 재현 입력을 직접 검증합니다.

## 내 결과

실행할 때마다 `output/day4-notebook-runs/날짜_실행ID/`에 새 파일을 만듭니다.
마지막의 `index.html`에서 리뷰·Excel·Word·PPT를 확인합니다.
처음 결제 코드는 의도적으로 테스트 4개가 실패합니다. `checkout.py`를 직접 수정하세요.
자동 수정은 기본으로 꺼져 있고, 별도 참고 구현의 테스트 통과와 내 코드의 통과를 구분합니다.

## 테스트

```bash
python -m pytest -q tests/test_day4_pr_review_lab.py tests/test_day4_excel_lab.py tests/test_day4_document_lab.py
```

실제 Google Sheets 성적표·회사 데이터·비밀키는 포함하지 않았습니다. Apps Script는 본인 소유의 합성 연습 시트에만 적용합니다.
GitHub Actions 파일은 `templates/` 안의 비활성 예시이며, 사람이 개인 저장소에 복사해야 실행됩니다.

`BUNDLE_MANIFEST.json`에 실제 포함 파일과 선택 자료의 누락 여부를 기록했습니다.
