"""Local Meeting Intelligence application."""
